<?php
    $dias=["lunes","martes","miercoles","jueves","viernes","sabado","domingo"];

    foreach ($dias as $dia ) {
        print("$dia ");
    }
?>